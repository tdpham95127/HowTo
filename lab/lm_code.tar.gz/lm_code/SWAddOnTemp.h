
#if (_LM_PHY_DIG_USE_INIT_ARRAY & _LM_PHY_DIG_USE_INIT_ARRAY_NVHS_ALT)

    // -----------------------------------------
    // Struct definition for ALT arrays
    // -----------------------------------------
    struct NvUphyTxEqPoint {
        enum { IGNORE = 3, USE = 0} tag: 2; // 11b = 3 indicates invalid, else expect this to be 00
        unsigned int cp1  : 5;
        unsigned int cm1  : 5;
        unsigned int cm2  : 4;
        unsigned int cm3  : 3;
    };
    
    // -----------------------------------------
    // ALT A0 ALT arrays
    // -----------------------------------------
    const struct NvUphyTxEqPoint NV_UPHY_NVHS_ALT_A0_PAM4_PRESET = {
         .tag=USE,      .cp1=0,  .cm1=0,   .cm2=0,   .cm3= 0
    };

    // -----------------------------------------
    // ALT CFSEARCH arrays for A1
    // -----------------------------------------
    #define NV_UPHY_NVHS_ALT_CFSEARCH_PAM4_PRESET_ARRAY_LEN 16

    const struct NvUphyTxEqPoint NV_UPHY_NVHS_ALT_CFSEARCH_PAM4_PRESET[NV_UPHY_NVHS_ALT_CFSEARCH_PAM4_PRESET_ARRAY_LEN] = {
        {.tag=USE,     .cp1=17,  .cm1= 2,  .cm2= 0,  .cm3= 0},
        {.tag=USE,     .cp1= 0,  .cm1= 4,  .cm2= 0,  .cm3= 0},
        {.tag=USE,     .cp1=12,  .cm1= 2,  .cm2= 0,  .cm3= 0},
        {.tag=USE,     .cp1=12,  .cm1= 7,  .cm2= 0,  .cm3= 0},
        {.tag=USE,     .cp1= 7,  .cm1= 2,  .cm2= 0,  .cm3= 0},
        {.tag=USE,     .cp1= 7,  .cm1= 7,  .cm2= 0,  .cm3= 0},
        {.tag=USE,     .cp1= 7,  .cm1=12,  .cm2= 0,  .cm3= 0},
        {.tag=USE,     .cp1= 2,  .cm1= 7,  .cm2= 0,  .cm3= 0},
        {.tag=IGNORE,  .cp1= 4,  .cm1=12,  .cm2= 0,  .cm3= 0},
        {.tag=IGNORE,  .cp1= 2,  .cm1= 2,  .cm2= 0,  .cm3= 0},
        {.tag=IGNORE,  .cp1= 2,  .cm1= 6,  .cm2= 0,  .cm3= 0},
        {.tag=IGNORE,  .cp1= 2,  .cm1=10,  .cm2= 0,  .cm3= 0},
        {.tag=IGNORE,  .cp1= 0,  .cm1= 8,  .cm2= 0,  .cm3= 0},
        {.tag=IGNORE,  .cp1= 0,  .cm1=12,  .cm2= 0,  .cm3= 0},
        {.tag=IGNORE,  .cp1= 0,  .cm1= 0,  .cm2= 0,  .cm3= 0},
        {.tag=IGNORE,  .cp1= 0,  .cm1= 4,  .cm2= 0,  .cm3= 0}
    };

#endif

