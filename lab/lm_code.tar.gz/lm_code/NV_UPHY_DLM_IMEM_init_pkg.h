#ifndef __LM_PHY_DIG_IMEM_INIT_PKG_H
#define __LM_PHY_DIG_IMEM_INIT_PKG_H

//  IMEM Init Package header for LM_PHY_DIG

//--------------------------------------------------------------------------------
//  NV_UPHY IMEM Common Init Package
//--------------------------------------------------------------------------------

#ifndef NV_UPHY_IMEM_INIT_PKG_H

    #define NV_UPHY_IMEM_INIT_PKG_H 1

    struct NvUphyImemCfgReg {
        NvU16 addr;
        NvU16 wdata;
    };

    struct NvUphyImemCfgData {
        NvU16 wdata;
    };

#endif

//--------------------------------------------------------------------------------
//  IMEM Register Init Arrays
//--------------------------------------------------------------------------------

    #define LM_PHY_DIG_IMEM_SETUP_NUM_ENTRIES 3

    const struct NvUphyImemCfgReg LM_PHY_DIG_IMEM_setup_init[LM_PHY_DIG_IMEM_SETUP_NUM_ENTRIES] = {
        {.addr = 0x3A0, .wdata = 0x0000},
        {.addr = 0x3A1, .wdata = 0x0000},
        {.addr = 0x3E3, .wdata = 0x0000}
    };

    #define LM_PHY_DIG_IMEM_DATA_ADDR 0x3E2

    #define LM_PHY_DIG_IMEM_DATA_NUM_ENTRIES 0

    const struct NvUphyImemCfgData LM_PHY_DIG_IMEM_data_init[] = {};

//--------------------------------------------------------------------------------
//  IMEM Sequence Arrays
//--------------------------------------------------------------------------------

// SEQ_IMEM_WR_EN initialization array
//
#define LM_PHY_DIG_SEQ_IMEM_WR_EN_NUM_ENTRIES 1

const struct NvUphyImemCfgReg LM_PHY_DIG_SEQ_IMEM_WR_EN_init[LM_PHY_DIG_SEQ_IMEM_WR_EN_NUM_ENTRIES] = {
    {.addr = 0x39D, .wdata = 0x0001}
};

// SEQ_IMEM_WR_DIS initialization array
//
#define LM_PHY_DIG_SEQ_IMEM_WR_DIS_NUM_ENTRIES 1

const struct NvUphyImemCfgReg LM_PHY_DIG_SEQ_IMEM_WR_DIS_init[LM_PHY_DIG_SEQ_IMEM_WR_DIS_NUM_ENTRIES] = {
    {.addr = 0x39D, .wdata = 0x0000}
};

// SEQ_IMEM_CHKSM_EN initialization array
//
#define LM_PHY_DIG_SEQ_IMEM_CHKSM_EN_NUM_ENTRIES 1

const struct NvUphyImemCfgReg LM_PHY_DIG_SEQ_IMEM_CHKSM_EN_init[LM_PHY_DIG_SEQ_IMEM_CHKSM_EN_NUM_ENTRIES] = {
    {.addr = 0x39D, .wdata = 0x0004}
};

// SEQ_IMEM_CHKSM_DIS initialization array
//
#define LM_PHY_DIG_SEQ_IMEM_CHKSM_DIS_NUM_ENTRIES 1

const struct NvUphyImemCfgReg LM_PHY_DIG_SEQ_IMEM_CHKSM_DIS_init[LM_PHY_DIG_SEQ_IMEM_CHKSM_DIS_NUM_ENTRIES] = {
    {.addr = 0x39D, .wdata = 0x0000}
};

//--------------------------------------------------------------------------------
//  Register Definitions for IMEM
//--------------------------------------------------------------------------------

//--------------------------------------------------------------------------------
//  End
//--------------------------------------------------------------------------------

#endif