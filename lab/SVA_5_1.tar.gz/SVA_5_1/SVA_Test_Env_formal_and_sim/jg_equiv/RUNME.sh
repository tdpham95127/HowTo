#!/bin/sh 
jg chk_equiv.tcl 
