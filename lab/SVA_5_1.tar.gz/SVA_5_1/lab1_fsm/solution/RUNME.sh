#!/bin/sh 
jg fsm_if_setup.tcl
