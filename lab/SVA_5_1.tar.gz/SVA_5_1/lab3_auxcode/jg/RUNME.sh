#!/bin/sh 
date;
jg setup_reqack.tcl
 
