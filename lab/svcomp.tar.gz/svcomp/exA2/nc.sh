#! /bin/csh -f

if ( ! -d lib ) mkdir lib
ncvlog -sv -work lib -linedebug cpu_part1.v
#ncvlog -sv -work lib -linedebug cpu_part2.v
if ( $status) exit 1
ncelab -access +rwc -work lib lib.test:module
if ( $status) exit 1
ncsim -gui lib.test -input nc.tcl &
