#! /bin/csh -f

if ( ! -d lib ) mkdir lib

ncvlog -sv -work lib -linedebug iface_assertions.sv
if ( $status) exit 1

# Use one of the following two lines
ncvlog -sv -work lib -linedebug iface_no_errors.v
#ncvlog -sv -work lib -linedebug iface.v
if ( $status) exit 1

ncelab -access +rwc -work lib lib.iface:module lib.bindings:module
if ( $status) exit 1

ncsim -gui lib.iface -input nc.tcl &
