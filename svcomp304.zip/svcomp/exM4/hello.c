// Module-Based SystemVerilog Verification - hello.c
// DPI exercise

// C function - to be called using SystemVerilog DPI

#include <stdio.h>

int hello ( int num_repeats )
{
	int i;
	const char what_to_say[] = "Hello, SystemVerilog!";

	for ( i = 0; i < num_repeats; i++ ) {
		printf( "%s\n", what_to_say );
	}

	return 0; // Not disabled (if called as imported task)
}
