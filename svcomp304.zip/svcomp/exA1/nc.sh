#! /bin/csh -f

if ( ! -d lib ) mkdir lib
ncvlog -sv -work lib -linedebug counter.v
ncvlog -work lib -linedebug countertb.v
ncelab -access +rwc -work lib lib.Countertb:module
ncsim -gui lib.Countertb -input nc.tcl &
